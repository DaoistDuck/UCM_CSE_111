-- SQLite

select MIN(s_acctbal)
from supplier;