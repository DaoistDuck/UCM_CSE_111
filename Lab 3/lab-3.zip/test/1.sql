-- SQLite

select c_address, c_phone, c_acctbal
from customer
where c_custkey = 000000010;
